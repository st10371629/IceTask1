﻿using Microsoft.AspNetCore.Mvc;

public class ShoppingController : Controller
{
    private static List<ShoppingItem> shoppingList = new List<ShoppingItem>();
    private static int nextId = 1;

    public ActionResult Index()
    {
        return View(shoppingList);
    }

    public ActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public ActionResult Create(ShoppingItem item)
    {
        item.Id = nextId++;
        shoppingList.Add(item);
        return RedirectToAction("Index");
    }

    public ActionResult Edit(int id)
    {
        var item = shoppingList.FirstOrDefault(i => i.Id == id);
        if (item == null)
            return NotFound();
        return View(item);
    }

    [HttpPost]
    public ActionResult Edit(ShoppingItem item)
    {
        var existingItem = shoppingList.FirstOrDefault(i => i.Id == item.Id);
        if (existingItem == null)
            return NotFound();

        existingItem.Name = item.Name;
        existingItem.Quantity = item.Quantity;
        existingItem.IsChecked = item.IsChecked;
        return RedirectToAction("Index");
    }

    public ActionResult Delete(int id)
    {
        var item = shoppingList.FirstOrDefault(i => i.Id == id);
        if (item == null)
            return NotFound();
        return View(item);
    }

    [HttpPost]
    [ActionName("Delete")]
    public ActionResult DeleteConfirmed(int id)
    {
        var item = shoppingList.FirstOrDefault(i => i.Id == id);
        if (item == null)
            return NotFound();
        shoppingList.Remove(item);
        return RedirectToAction("Index");
    }
}
