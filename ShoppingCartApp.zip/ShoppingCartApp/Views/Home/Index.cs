﻿using Microsoft.AspNetCore.Mvc;

namespace ShoppingCartApp.Views.Home
{
    public class Index : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
